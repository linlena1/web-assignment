let calculator = {
    read: (a, b) => {
        calculator.a = a;
        calculator.b = b;
    },

    sum: () => {
        return calculator.a + calculator.b;
    },

    mul: () => {
        return calculator.a * calculator.b;
    }
};

//test
calculator.read(1, 2);
console.log(calculator.sum());  
console.log(calculator.mul()); 
