for (let n = 10; n <= 100; n++) {
    if (n % 3 == 0 && n % 5 == 0) {
        console.log(n + "은 3과 5의 배수입니다");
    } else if (n % 3 == 0) {
        console.log(n + "은 3의 배수입니다");
    } else if (n % 5 == 0) {
        console.log(n + "은 5의 배수입니다");
    }
}
//while
let n = 10;

while (n <= 100) {
    if (n % 3 == 0 && n % 5 == 0) {
        console.log(n + "은 3과 5의 배수입니다");
    } else if (n % 3 == 0) {
        console.log(n + "은 3의 배수입니다");
    } else if (n % 5 == 0) {
        console.log(n + "은 5의 배수입니다");
    }

    n++;
}
