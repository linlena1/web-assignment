const max = function(n1, n2) {
    if (n1 > n2) {
        return n1;
    } else {
        return n2;
    }
};

const factorial = function(n) {
    let result = 1;

    for (let i = 1; i <= n; i++) {
        result = result * i;
    }

    return result;
};

const pibo = function(n) {
    let a = 1;
    let b = 1;

    if (n == 1 || n == 2) {
        return 1;
    }

    for (let i = 3; i <= n; i++) {
        let c = a + b;
        a = b;
        b = c;
    }

    return b;
};

const calc = function(n1, n2, operator) {
    if (operator == "+") {
        return n1 + n2;
    } else if (operator == "-") {
        return n1 - n2;
    } else if (operator == "*") {
        return n1 * n2;
    } else if (operator == "/") {
        return n1 / n2;
    }
};

console.log(max(2, 5));
console.log(factorial(3));
console.log(pibo(6));
console.log(calc(3, 5, "+"));
console.log(calc(8, 2, "/"));
