for (let n = 2; n <= 100; n++) {
    let prime = true;

    for (let i = 2; i < n; i++) {
        if (n % i == 0) {
            prime = false;
        }
    }

    if (prime == true) {
        console.log(n + "은 소수입니다");
    }
}
