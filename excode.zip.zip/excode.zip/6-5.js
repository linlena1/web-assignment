function Account(owner, balance) {
    this.owner = owner;
    this.balance = balance;

    this.deposit = function(amount) {
        this.balance = this.balance + amount;
    };

    this.withdraw = function(amount) {
        this.balance = this.balance - amount;
    };

    this.getBalance = function() {
        return this.balance;
    };
}

// test 6-5-2

function Account(owner, balance) {
    this.owner = owner;
    this.balance = balance;

    this.deposit = function(amount) {
        this.balance = this.balance + amount;
    };

    this.withdraw = function(amount) {
        this.balance = this.balance - amount;
    };

    this.getBalance = function() {
        return this.balance;
    };
}

let account1 = new Account("John", 1000000);

console.log(account1.owner);
console.log(account1.getBalance());

account1.withdraw(100000);
console.log(account1.getBalance());

account1.deposit(500000);
console.log(account1.getBalance());
