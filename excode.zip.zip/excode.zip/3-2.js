
let year = 2024;

if (year % 400 == 0) {
    console.log(year + "년은 윤년입니다");
} else if (year % 100 == 0) {
    console.log(year + "년은 평년입니다");
} else if (year % 4 == 0) {
    console.log(year + "년은 윤년입니다");
} else {
    console.log(year + "년은 평년입니다");
}

