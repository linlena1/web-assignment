let n = 7;

console.log("구구단 " + n + "단");

for (let i = 1; i <= 9; i++) {
    console.log(n + " x " + i + " = " + (n * i));
}
