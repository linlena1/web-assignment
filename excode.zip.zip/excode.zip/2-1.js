

console.log(15 - 5 * (7 + 2 * 3) ** 2);


console.log(5 * (2 + (5 - 3) / 4) * 128);


console.log(((3 ** 3 - 2) % 5 + 2) ** 2);



let x = 2;
let y = 1;

console.log(x ** (2 * y) * (x + 5) * Math.log2(x));

console.log(x * Math.sqrt(2 - 2 * Math.sin(y)));



let r = 5;
let area = 3.14 * r * r;

console.log("원의 넓이 =", area);



let a = 1;
let b = -5;
let c = 6;

let d = b * b - 4 * a * c;

let root1 = (-b + Math.sqrt(d)) / (2 * a);
let root2 = (-b - Math.sqrt(d)) / (2 * a);

console.log("첫 번째 근 =", root1);
console.log("두 번째 근 =", root2);
